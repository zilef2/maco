<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();
	    $this->call([
            PermissionSeeder::class,
            RoleSeeder::class,
            UserSeeder::class,
            ParametrosSeeder::class,
            SeederParametroMaterialesTaller::class,
            SeederParametroCostosPromedio::class,
            ListaDesplegableSeeder::class,
            EstadoOperacionSeeder::class,
            MaterialSeeder::class,
            ProductoSeeder::class,
            FichaTecnicaMaterialesSeeder::class,
            // NotificacionSeeder::class,
            TallerSeeder::class,
            EmpresaExternaSeeder::class,
            EstadoOpMaterialSeeder::class,
        ]);
    }
}
