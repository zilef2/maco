<?php

namespace App\Services;

use App\Models\FichaTecnica;
use App\Models\Material;
use App\Models\OrdenProduccion;
use App\Models\Producto;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Una ficha técnica agrupa los materiales que consume un producto.
 * Este servicio concentra las opciones del formulario y el guardado, para que
 * el alta se pueda hacer tanto desde la ficha como desde "Nuevo producto".
 */
class FichaTecnicaService
{
    /** Estados de OP que todavía permiten editar la ficha del producto. */
    public const ESTADOS_FICHA_EDITABLE = ['Borrador', 'Preparación', 'Cerrada'];

    public function __construct(
        protected ListaDesplegableService $listaDesplegableService,
        protected CostoMaterialOpService $costosMateriales
    ) {}

    /**
     * Opciones para las líneas de material (material, unidad y costo vigente).
     */
    public function opcionesMateriales(): array
    {
        $materiales = Material::with('lastPrice')
            ->orderBy('nombre_base')
            ->get(['id', 'codigo_material', 'nombre_base', 'unidad_inventario'])
            ->map(fn ($m) => [
                'id'    => $m->id,
                'value' => $m->id,
                'name'  => trim(($m->codigo_material ? $m->codigo_material . ' — ' : '') . $m->nombre_base) ?: ('Material #' . $m->id),
                'unidad_inventario' => $m->unidad_inventario,
                'unidad_medida' => $m->unidad_inventario,
                'costo_unitario' => $m->costoUnitarioActual(),
                'precio_registrado' => $m->lastPrice !== null,
            ])->values()->all();

        $opcionesMaterial = $this->listaDesplegableService->getOptionsByCategoriaGrouped('material');
        $unidadesMedida = array_map(fn ($item) => [
            'id'    => $item['nombre'],
            'value' => $item['nombre'],
            'name'  => $item['nombre'],
            'label' => $item['nombre'],
        ], $opcionesMaterial['unidad_inventario'] ?? []);

        return [
            'materiales'    => $materiales,
            'unidad_medida' => $unidadesMedida,
        ];
    }

    /**
     * Opciones completas del formulario de ficha (materiales, unidades y productos).
     */
    public function opcionesFicha(): array
    {
        $productos = Producto::all(['id', 'Titulo_Shopify', 'Codigo_interno'])
            ->map(function ($p) {
                $nombre = $p->Titulo_Shopify ?: ($p->Codigo_interno ?: 'Producto #' . $p->id);
                return [
                    'id'    => $p->id,
                    'value' => $p->id,
                    'name'  => $nombre,
                    'label' => $nombre,
                    'title' => $nombre,
                ];
            })->values()->all();

        $productosConFicha = DB::table('ficha_tecnica_producto')->pluck('producto_id')->all();
        $productosSinFicha = array_values(array_filter(
            $productos,
            fn ($p) => !in_array($p['id'], $productosConFicha)
        ));

        return $this->opcionesMateriales() + [
            'productos'           => $productos,
            'productos_sin_ficha' => $productosSinFicha,
        ];
    }

    /**
     * OPs que impiden editar la ficha de un producto: cualquier OP activa
     * (fuera de Borrador, Preparación o Cerrada).
     *
     * @return array<string, string> número de OP => estado
     */
    public function operacionesQueBloquean(int $productoId): array
    {
        $producto = Producto::find($productoId);
        if (!$producto) {
            return [];
        }

        return $producto->ordenesProduccion()
            ->with('estadoOp:id,nombre')
            ->get()
            ->reject(fn ($op) => in_array($op->estadoOp?->nombre, self::ESTADOS_FICHA_EDITABLE, true))
            ->mapWithKeys(fn ($op) => [
                ($op->numero_op ?? $op->id) => ($op->estadoOp?->nombre ?? 'sin estado'),
            ])
            ->all();
    }

    /**
     * Mapa producto_id => [número de OP => estado] con las OPs que bloquean
     * la ficha. Se usa en el listado para no consultar producto por producto.
     *
     * @return array<int, array<string, string>>
     */
    public function bloqueosPorProducto(): array
    {
        $bloqueos = [];

        OrdenProduccion::with(['productos:id', 'estadoOp:id,nombre'])
            ->get()
            ->each(function ($op) use (&$bloqueos) {
                if (in_array($op->estadoOp?->nombre, self::ESTADOS_FICHA_EDITABLE, true)) {
                    return;
                }

                foreach ($op->productos as $producto) {
                    $bloqueos[$producto->id][$op->numero_op ?? $op->id] = $op->estadoOp?->nombre ?? 'sin estado';
                }
            });

        return $bloqueos;
    }

    /**
     * Crea o actualiza la ficha con sus materiales y productos.
     * Un producto solo puede pertenecer a una ficha (ficha única por producto).
     * No se puede modificar si el producto está en una OP activa.
     *
     * @param  array{nombre: string, productos?: array, materiales: array}  $datos
     */
    public function guardar(array $datos, ?FichaTecnica $ficha = null): FichaTecnica
    {
        $productoIds = array_map('intval', $datos['productos'] ?? []);

        $bloqueos = [];
        foreach ($productoIds as $productoId) {
            $bloqueos += $this->operacionesQueBloquean($productoId);
        }
        if (!empty($bloqueos)) {
            $detalle = collect($bloqueos)
                ->map(fn ($estado, $numeroOp) => $numeroOp . ' (' . $estado . ')')
                ->implode(', ');
            throw ValidationException::withMessages([
                'productos' => 'La ficha técnica no se puede modificar: el producto está en la OP ' . $detalle
                    . '. Solo se permite en Borrador, Preparación o Cerrada.',
            ]);
        }

        $enOtraFicha = FichaTecnica::productosConFicha($productoIds, $ficha?->id);
        if (!empty($enOtraFicha)) {
            $nombres = Producto::whereIn('id', $enOtraFicha)->get()
                ->map(fn ($p) => $p->Titulo_Shopify ?: ($p->Codigo_interno ?: 'Producto #' . $p->id))
                ->implode(', ');
            throw ValidationException::withMessages([
                'productos' => __('app.label.ficha_ya_asignada') . ': ' . $nombres,
            ]);
        }

        // El costo real no se captura por ahora: al editar se conserva el valor previo.
        $costosRealesPrevios = $ficha
            ? $ficha->materiales()->pluck('costo_asociado_real', 'material_componente_id')
            : collect();

        // Unidad y costo unitario son datos del material, no de la ficha.
        $materialesPorId = Material::with('lastPrice')
            ->whereIn(
                'id',
                collect($datos['materiales'])
                    ->pluck('material_componente_id')
                    ->map(fn ($id) => (int) $id)
                    ->filter()
                    ->unique()
            )
            ->get()
            ->keyBy('id');

        if (!$ficha) {
            $ficha = FichaTecnica::create(['nombre' => $datos['nombre']]);
        } else {
            $ficha->update(['nombre' => $datos['nombre']]);
        }

        $ficha->materiales()->delete();
        foreach ($datos['materiales'] as $fila) {
            $materialId = (int) $fila['material_componente_id'];
            $material = $materialesPorId->get($materialId);

            $ficha->materiales()->create([
                'material_componente_id'   => $materialId,
                'consumo_estandar'         => $fila['consumo_estandar'],
                // La ficha conserva una copia para el histórico; el origen es el material.
                'unidad_medida'            => $material?->unidad_inventario ?? ($fila['unidad_medida'] ?? null),
                'costo_asociado_teorico'   => $material
                    ? $material->costoUnitarioActual()
                    : ($fila['costo_asociado_teorico'] ?? 0),
                'costo_asociado_real'      => array_key_exists('costo_asociado_real', $fila)
                    ? $fila['costo_asociado_real']
                    : ($costosRealesPrevios[$materialId] ?? null),
            ]);
        }

        $ficha->productos()->sync($productoIds);

        // Las OPs abiertas que usan estos productos deben costearse con la ficha
        // nueva: su precio guardado y su historial de cambios se renuevan.
        $this->costosMateriales->recalcularPorProductos($productoIds);

        return $ficha->refresh();
    }
}
