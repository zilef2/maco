<?php

namespace App\Http\Requests\User;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UserStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name'              => 'required|string|max:255',
            'email'             => ['required', 'string', 'email', 'max:255', Rule::unique('users', 'email')],
            'role'              => ['required'],

            'identificacion'    => ['required'],
            'salario'           => ['nullable'],
            'celular'           => ['nullable'],
            'fecha_de_ingreso'  => ['nullable'],
            'sexo'              => ['nullable'],
            'area'              => ['nullable', 'string', 'max:255'],
            'cargo'             => ['nullable', 'string', 'max:255'],
            'fecha_nacimiento'  => ['nullable', 'date'],
        ];
    }
}
