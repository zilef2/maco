<?php

namespace App\Http\Controllers;

use App\helpers\HelpExcel;
use App\helpers\Myhelp;
use App\helpers\MyModels;
use App\Http\Requests\User\UserIndexRequest;
use App\Http\Requests\User\UserStoreRequest;
use App\Http\Requests\User\UserUpdateRequest;
use App\Imports\PersonalImport;
use App\Jobs\ImportarUsuariosJob;
use App\Models\Permission;
use App\Models\Reporte;
use App\Models\Role;
use App\Models\User;
use App\Exports\MultipleExport;
use App\Models\Producto;
use App\Services\ExcelUsuariosService;
use App\Services\ImportacionExcelNotificador;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;

class UserController extends Controller
{
    public $thisAtributos;

    public function __construct()
    {
//        $this->middleware('permission:create user', ['only' => ['create', 'store']]);
//        $this->middleware('permission:read user', ['only' => ['index', 'show']]);
//        $this->middleware('permission:update user', ['only' => ['edit', 'update']]);
//        $this->middleware('permission:delete user', ['only' => ['destroy', 'destroyBulk']]);
        $this->thisAtributos = (new User())->getFillable(); //not using

    }

    //esto es de comercio
    public function Dashboard()
    {
        $numberPermissions = MyModels::getPermissionToNumber(Myhelp::EscribirEnLog($this, ' Dashboard'));
        if ($numberPermissions > 1) {

            return Inertia::render('Dashboard', [
                'users' => (int)User::count(),
                'roles' => (int)Role::count(),
                'productos' => (int)Producto::count(),
            ]);
        } else {
            return redirect()->route('reporte.index');
        }

    }

    public function index(UserIndexRequest $request)
    {
        $userId = auth()->id();
        $role   = auth()->user()->roles->pluck('name')[0];

        $numberPermissions = Cache::remember(
            "user_permissions_{$userId}",
            now()->addMinutes(10),
            fn () => MyModels::getPermissionToNumber(Myhelp::EscribirEnLog($this, ' users'))
        );

        $roles = Cache::remember(
            "roles_list_{$role}",
            now()->addMinutes(10),
            function () use ($role) {
                if ($role === 'superadmin') {
                    return Role::get();
                }
                return Role::where('name', '<>', 'superadmin')->where('name', '<>', 'admin')->get();
            }
        );

        $users = User::query();

        if ($request->has('search')) {
            $users->where(function ($query) use ($request) {
                $query->where('name', 'LIKE', "%" . $request->search . "%")
                    ->orWhere('email', 'LIKE', "%" . $request->search . "%")
                    ->orWhere('identificacion', 'LIKE', "%" . $request->search . "%");
            })->where('name', '!=', 'admin')->where('name', '!=', 'Superadmin');
        }

        if ($request->has(['field', 'order'])) {
            $users = $users->orderBy($request->field, $request->order);
        } else {
            $users = $users->orderBy('updated_at', 'desc');
        }

        $perPage = $request->has('perPage') ? $request->perPage : 10;

        if ($role !== 'superadmin') {
            $users->whereHas('roles', function ($query) {
                return $query->whereNotIn('name', ['superadmin', 'admin']);
            });
        }

        if ($role === 'admin') {
            $users->whereHas('roles', function ($query) {
                return $query->where('name', '<>', 'superadmin');
            });
        }

        return Inertia::render('User/Index', [
            'breadcrumbs'      => [['label' => __('app.label.user'), 'href' => route('user.index')]],
            'title'            => __('app.label.user'),
            'filters'          => $request->all(['search', 'field', 'order']),
            'perPage'          => (int) $perPage,
            'users'            => $users->with('roles')->paginate($perPage),
            'roles'            => $roles,
            'numberPermissions'=> $numberPermissions,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    //! STORE - UPDATE - DELETE
    //! STORE functions
    public function updatingDate($date)
    {
        if ($date === null || $date === '' || $date == '1969-12-31') {
            return null;
        }
        $timestamp = strtotime($date);
        return $timestamp === false ? null : date("Y-m-d", $timestamp);
    }

    public function store(UserStoreRequest $request)
    {
        $permissions = Myhelp::EscribirEnLog($this, 'STORE:users');
        $user = Auth::user();
        DB::beginTransaction();
        try {
            if (isset($request->sexo['value'])) {
                $sexo = is_string($request->sexo) ? $request->sexo : $request->sexo['value'];
            } else {
                $sexo = 'Masculino';
            }
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,

                'cargo' => $request->cargo,
                'identificacion' => $request->identificacion,
                'celular' => $request->celular,
                'sexo' => $sexo,
                'fecha_nacimiento' => $this->updatingDate($request->fecha_nacimiento),
                'password' => Hash::make($request->identificacion . '*'),
            ]);
            $user->assignRole($request->role);
            DB::commit();
            Cache::forget('roles_list_superadmin');
            Cache::forget('roles_list_admin');
            Cache::forget('roles_list_user');
            Myhelp::EscribirEnLog($this, 'STORE:users', 'usuario id:' . $user->id . ' | ' . $user->name . ' guardado', false);

            return back()->with('success', __('app.label.created_successfully', ['name' => $user->name]));
        } catch (\Throwable $th) {
            DB::rollback();
            Myhelp::EscribirEnLog($this, 'STORE:users', 'usuario id:' . $user->id . ' | ' . $user->name . ' fallo en el guardado', false);
            return back()->with('error', __('app.label.created_error', ['name' => __('app.label.user')]) . $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile());
        }
    }

    //fin store functions
    public function show($id)
    {
    }

    public function edit($id)
    {
    }

    public function update(UserUpdateRequest $request, $id)
    {
        Myhelp::EscribirEnLog($this, 'UPDATE:users', '', false);
        DB::beginTransaction();
        try {
            if($request->sexo)
                $sexo = is_string($request->sexo) ? $request->sexo : $request->sexo['value'];
            
            $user = User::findOrFail($id);
            $user->update([
                'name' => $request->name,
                'email' => $request->email,

                'cargo' => $request->cargo,
                'identificacion' => $request->identificacion,
                'celular' => $request->celular,
                'sexo' => $sexo,
                'fecha_nacimiento' => $this->updatingDate($request->fecha_nacimiento),
            ]);

            $user->syncRoles($request->role);
            DB::commit();
            Cache::forget("user_permissions_{$id}");
            Myhelp::EscribirEnLog($this, 'UPDATE:users', 'usuario id:' . $user->id . ' | ' . $user->name . ' actualizado', false);
            return back()->with('success', __('app.label.updated_successfully', ['name' => $user->name]));
        } catch (\Throwable $th) {
            $user = User::findOrFail($id);

            DB::rollback();
            Myhelp::EscribirEnLog($this, 'UPDATE:users', 'usuario id:' . $user->id . ' | ' . $user->name . '  fallo en el actualizado', false);
            return back()->with('error', __('app.label.updated_error', ['name' => $user->name]) . $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(User $user)
    {
        $permissions = Myhelp::EscribirEnLog($this, 'DELETE:users');

        try {
            $user->delete();
            Myhelp::EscribirEnLog($this, 'DELETE:users', 'usuario id:' . $user->id . ' | ' . $user->name . ' borrado', false);
            return back()->with('success', __('app.label.deleted_successfully', ['name' => $user->name]));
        } catch (\Throwable $th) {
            $stringUser = $user->id . ' | ' . $user->name ?? ' usuario no encontrado';
            $therror = $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile();
            Myhelp::EscribirEnLog($this, 'DELETE:users', 'usuario id:' . $stringUser . ' fallo en el borrado:: ' . $therror, false);
            return back()->with('error', __('app.label.deleted_error', ['name' => $user->name]) . $therror);
        }
    }

    public function destroyBulk(Request $request)
    {
        try {
            $users = User::whereIn('id', $request->id);
            $count = count($request->id);
            if ($count > 9) {
                return back()->with('error', 'Son demasiados usuarios para eliminarlos, intente de nuevo');
            }
            $users->delete();
            return back()->with('success', 'Se han eliminado ' . $count . ' usuarios');
        } catch (\Throwable $th) {
            return back()->with('error', __('app.label.deleted_error', ['name' => count($request->id) . ' ' . __('app.label.user')]) . $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile());
        }
    }

    //FIN : STORE - UPDATE - DELETE

    /**
     * Carga masiva de usuarios desde Excel.
     *
     * Valida de forma síncrona (tamaño, escaneo de seguridad, columnas y
     * filas) y solo si todo está correcto encola el job que inserta en la BD,
     * envía los correos y crea la notificación de finalización.
     */
    public function uploadExcel(
        Request $request,
        ExcelUsuariosService $excel,
        ImportacionExcelNotificador $notificador,
    ): RedirectResponse {
        Myhelp::EscribirEnLog($this, 'uploadExcel:users: inicio');

        $request->validate([
            'archivo' => ['required', 'file', 'max:10240', 'mimes:xlsx'],
        ], [
            'archivo.required' => 'Selecciona un archivo .xlsx.',
            'archivo.file' => 'El archivo no es válido.',
            'archivo.max' => 'El archivo supera el tamaño máximo de 10 MB.',
            'archivo.mimes' => 'Solo se permiten archivos .xlsx.',
        ]);

        $archivo = $request->file('archivo');
        $usuario = $request->user();
        $nombreArchivo = $archivo->getClientOriginalName();
        $rutaRelativa = null;

        try {
            if (strtolower($archivo->getClientOriginalExtension()) !== 'xlsx') {
                throw new \RuntimeException('Solo se permiten archivos con extensión .xlsx.');
            }

            // 1. Escaneo de seguridad del contenedor XLSX.
            $problemas = $excel->escanearSeguridad($archivo->getRealPath());
            if (!empty($problemas)) {
                throw new \RuntimeException(implode(' | ', $problemas));
            }

            // 2. Fila 1 = títulos; el resto datos. Valida columnas y filas.
            $excel->leerRegistros($archivo->getRealPath());

            // 3. Todo válido: guardar y encolar la importación.
            $rutaRelativa = $archivo->store('imports/usuarios', 'local');
            if (!$rutaRelativa) {
                throw new \RuntimeException('No se pudo guardar el archivo para su procesamiento.');
            }

            ImportarUsuariosJob::dispatch(
                $rutaRelativa,
                $nombreArchivo,
                $usuario?->email,
                $usuario?->name,
                $usuario?->id,
            );

            Myhelp::EscribirEnLog($this, 'uploadExcel:users ENCOLADO', $nombreArchivo);

            return back()->with(
                'success',
                'Archivo validado correctamente. La importación se está procesando; '
                . 'en breve podrás ver la información actualizada.'
            );
        } catch (\Throwable $e) {
            if ($rutaRelativa) {
                \Illuminate\Support\Facades\Storage::disk('local')->delete($rutaRelativa);
            }

            $notificador->fallo($usuario?->email, $usuario?->name, $nombreArchivo, 'usuarios', $e);
            Myhelp::EscribirEnLog($this, 'uploadExcel:users ERROR', $e->getMessage());

            return back()->with('error', 'No se importó nada: ' . $e->getMessage());
        }
    }

    public function subirexceles()
    { //just  a view
        $permissions = Myhelp::EscribirEnLog($this, ' materia');
        $numberPermissions = MyModels::getPermissionToNumber($permissions);

        return Inertia::render('User/subirExceles', [
            'breadcrumbs' => [['label' => __('app.label.user'), 'href' => route('user.index')]],
            'title' => __('app.label.user'),
            'numUsuarios' => count(User::all()) - 1,
            // 'UniversidadSelect'   => Universidad::all()
        ]);
    }


    // Duplicate entry '1152194566' for key 'users_identificacion_unique'
    private function MensajeWar()
    {
        $bandera = false;
        $contares = [
            'contar1',
            'contar2',
            'contar3',
            'contar4',
            'contar5',
            'contarVacios',
        ];
        $mensajesWarnings = [
            '#correos Existentes: ',
            'Novedad, error interno: ',
            '#cedulas no numericas: ',
            '#generos distintos(M,F,otro): ',
            '#identificaciones repetidas: ',
            '#filas con celdas vacias: ',
        ];

        foreach ($contares as $key => $value) {
            $$value = session($value, 0);
            session([$value => 0]);
            $bandera = $bandera || $$value > 0;
        }
        session(['contar2' => -1]);

        $mensaje = '';
        if ($bandera) {
            foreach ($mensajesWarnings as $key => $value) {
                if (${$contares[$key]} > 0) {
                    $mensaje .= $value . ${$contares[$key]} . '. ';
                }
            }
        }

        return $mensaje;
    }

    public function uploadtrabajadors(Request $request)
    {
        Myhelp::EscribirEnLog($this, get_called_class(), 'Empezo a importar', false);
        $countfilas = 0;
        try {
            if ($request->archivo1) {

                $helpExcel = new HelpExcel();
                $mensageWarning = $helpExcel->validarArchivoExcel($request);
                if ($mensageWarning != '') return back()->with('warning', $mensageWarning);

                Excel::import(new PersonalImport(), $request->archivo1);

                $countfilas = session('CountFilas', 0);
                session(['CountFilas' => 0]);

                $MensajeWarning = $this->MensajeWar();
                if ($MensajeWarning !== '') {
                    return back()->with('success', 'Usuarios nuevos: ' . $countfilas)
                        ->with('warning', $MensajeWarning);
                }

                Myhelp::EscribirEnLog($this, 'IMPORT:users', ' finalizo con exito', false);
                if ($countfilas == 0)
                    return back()->with('success', __('app.label.op_successfully') . ' No hubo cambios');
                else
                    return back()->with('success', __('app.label.op_successfully') . ' Se leyeron ' . $countfilas . ' filas con exito');
            } else {
                return back()->with('error', __('app.label.op_not_successfully') . ' archivo no seleccionado');
            }
        } catch (\Throwable $th) {
            Myhelp::EscribirEnLog($this, 'IMPORT:users', ' Fallo importacion: ' . $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile(), false);
            return back()->with('error', __('app.label.op_not_successfully') . ' Usuario del error: ' . session('larow')[0] . ' error en la iteracion ' . $countfilas . ' ' . $th->getMessage() . ' L:' . $th->getLine() . ' Ubi: ' . $th->getFile());
        }
    }

    public function todaBD()
    {
        return Excel::download(new MultipleExport, 'macoDB.xlsx');
    }
    
    public function RRepor()
    {
        $usuariosConUltimoReporte = User::has('reportes')->get();
        $reportes = [];
        foreach ($usuariosConUltimoReporte as $item) {
            $elmodelo = $item->reportes->first();
            if ($elmodelo) {
                $reportes[] = [
                    $item->name,
                    $elmodelo->fecha,
                    $elmodelo->hora_inicial,
                    $elmodelo->hora_final,
                ];
            }
        }

        $reportesu = Reporte::all();
        foreach ($reportesu as $index => $reporte) {
            if ($reporte->hora_final) {
                $horaInicial = Carbon::parse($reporte->hora_inicial);
                $horafinal = Carbon::parse($reporte->hora_final);
                $tiemtras = zilef_nuber_format($horafinal->diffInSeconds($horaInicial) / 60, 3);
                $repor = [
                    'tiempo_transcurrido' => $tiemtras
                ];
                $reporte->update($repor);
            }
        }

        dd(
            $reportes,
            $reportes[0],
            $reportes[1] ?? 'no existe',
            $reportes[2] ?? 'no existe',
            $reportes[3] ?? 'no existe',
        );

    }
	
	 /**
     * Devuelve los datos del reporte en formato JSON para la API (Power BI).
     */
    public function indexApi(): \Illuminate\Http\JsonResponse
    {
        $genericou = User::select([
            'id',
	        'name as Operario',
	        'email',
	        'identificacion',
	        'sexo',
	        'fecha_nacimiento',
	        'celular',
	        'cargo',
        ])->where('name', '!=', 'Superadmin')
	        ->whereHas('roles', function ($query) {
                return $query->whereNotIn('name', ['superadmin', 'admin']);
            })
          ->get();

        return response()->json($genericou);
    }
}
