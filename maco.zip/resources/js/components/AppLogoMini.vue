<script setup lang="ts">
import AppLogoIconMini from '@/components/AppLogoIconMini.vue';
import { usePage } from '@inertiajs/vue3';

const page = usePage();
const name = page.props.name;

</script>

<template>
    <div
        class="flex aspect-square size-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
        <AppLogoIconMini class="max-w-[600px] size-5 fill-current text-white dark:text-black" />
    </div>
    <div class="ml-1 grid flex-1 text-left text-sm">
        <span class="mb-0.5 truncate font-semibold leading-none">{{ name }}</span>
    </div>
</template>
