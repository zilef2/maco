<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"  class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => ($appearance ?? 'system') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        
        
        
        <script>
            (function() {
                const appearance = '<?php echo e($appearance ?? "system"); ?>';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.ts']); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

        
        <?php if(request()->routeIs('OrdenProduccion.index')): ?>
        <script>
            (function () {
                var app = document.getElementById('app');
                if (!app) return;

                var fila =
                    '<div class="flex items-center gap-4 py-3 border-t border-gray-200 dark:border-gray-700">' +
                        '<div class="h-4 w-4 rounded bg-gray-200 dark:bg-gray-800 animate-pulse"></div>' +
                        '<div class="h-4 w-10 rounded bg-gray-200 dark:bg-gray-800 animate-pulse"></div>' +
                        '<div class="h-4 flex-1 rounded bg-gray-200 dark:bg-gray-800 animate-pulse"></div>' +
                        '<div class="h-4 w-20 rounded bg-gray-200 dark:bg-gray-800 animate-pulse"></div>' +
                        '<div class="h-4 w-16 rounded bg-gray-200 dark:bg-gray-800 animate-pulse"></div>' +
                    '</div>';

                var filas = '';
                for (var i = 0; i < 8; i++) { filas += fila; }

                app.innerHTML =
                    '<div class="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-6">' +
                        '<div class="h-8 w-52 rounded bg-gray-200 dark:bg-gray-800 animate-pulse mb-6"></div>' +
                        '<div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-4">' +
                            '<div class="flex gap-3 mb-4">' +
                                '<div class="h-9 w-28 rounded bg-gray-200 dark:bg-gray-700 animate-pulse"></div>' +
                                '<div class="h-9 w-40 rounded bg-gray-200 dark:bg-gray-700 animate-pulse"></div>' +
                            '</div>' +
                            filas +
                        '</div>' +
                    '</div>';
            })();
        </script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\maco\resources\views\app.blade.php ENDPATH**/ ?>