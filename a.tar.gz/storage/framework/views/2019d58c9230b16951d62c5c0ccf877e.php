<p>Estimado(a),</p>

<p><?php echo e($detalle['mensaje']); ?></p>
<?php /**PATH C:\laragon\www\maco\resources\views\emails\proceso\dllo\viaticogeneradou.blade.php ENDPATH**/ ?>