<?php

require __DIR__ . '/../../vendor/autoload.php';
$app = require __DIR__ . '/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\EstadoOperacion;
use App\Models\Material;
use App\Models\OrdenProduccion;
use App\Models\Producto;
use App\Models\User;
use App\Services\FichaTecnicaService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

Auth::login(User::whereHas('roles', fn ($q) => $q->whereIn('name', ['superadmin', 'admin']))->first());

$servicio = app(FichaTecnicaService::class);
$material = Material::first();
$preparacion = EstadoOperacion::where('nombre', 'Preparación')->value('id');
$enTaller = EstadoOperacion::where('nombre', 'En taller')->value('id');

$payloadProducto = fn (string $titulo) => [
    'Codigo_interno' => 'TMP-EDIT-001',
    'Titulo_Shopify' => $titulo,
    'ID_producto_Shopify' => '',
    'Categoria_original' => '',
    'Familia_normalizada' => '',
    'Control_de_variante' => '',
    'Opciones' => '',
    'Estado' => 1,
    'Observaciones' => '',
    'descripcion' => 'desc',
    'precio_predicho' => '',
    'precio_preventa' => '',
];

DB::beginTransaction();
try {
    $producto = Producto::create([
        'Codigo_interno' => 'TMP-EDIT-001',
        'Titulo_Shopify' => 'Producto editable',
        'ID_producto_Shopify' => '',
        'Categoria_original' => '',
        'Familia_normalizada' => '',
        'Control_de_variante' => '',
        'Opciones' => '',
        'Estado' => 1,
    ]);

    $ficha = $servicio->guardar([
        'nombre' => 'Ficha temporal',
        'productos' => [$producto->id],
        'materiales' => [[
            'material_componente_id' => $material->id,
            'consumo_estandar' => 1,
            'unidad_medida' => 'und',
            'costo_asociado_teorico' => 100,
        ]],
    ]);
    echo 'ficha creada: ' . $ficha->id . PHP_EOL;

    // OP en "En taller" (bloquea).
    $op = OrdenProduccion::create([
        'numero_op' => 'OP-TMP-BLOQUEO',
        'cantidad_planificada' => 1,
        'estado_op_id' => $enTaller,
        'user_id' => Auth::id(),
    ]);
    $op->productos()->sync([$producto->id]);

    echo 'bloqueos: ' . json_encode($servicio->operacionesQueBloquean($producto->id), JSON_UNESCAPED_UNICODE) . PHP_EOL;

    $payload = $payloadProducto('Titulo actualizado sin ficha');
    $request = Illuminate\Http\Request::create('/x', 'PUT', $payload);
    $request->setLaravelSession(app('session')->driver());
    app(App\Http\Controllers\ProductoController::class)->update($request, $producto->id);
    echo 'update sin materiales: ' . $producto->fresh()->Titulo_Shopify . PHP_EOL;

    $conMateriales = $payloadProducto('Titulo con ficha');
    $conMateriales['materiales'] = [[
        'material_componente_id' => $material->id,
        'consumo_estandar' => 9,
        'unidad_medida' => 'und',
        'costo_asociado_teorico' => 999,
    ]];
    $request2 = Illuminate\Http\Request::create('/x', 'PUT', $conMateriales);
    $request2->setLaravelSession(app('session')->driver());
    try {
        app(App\Http\Controllers\ProductoController::class)->update($request2, $producto->id);
        echo 'ERROR: permitió modificar la ficha bloqueada' . PHP_EOL;
    } catch (Illuminate\Validation\ValidationException $e) {
        echo 'bloqueo: ' . collect($e->errors())->flatten()->first() . PHP_EOL;
    }

    // OP en Preparación (permitido).
    OrdenProduccion::whereKey($op->id)->update(['estado_op_id' => $preparacion]);
    echo 'bloqueos con Preparación: ' . count($servicio->operacionesQueBloquean($producto->id)) . PHP_EOL;
    $servicio->guardar([
        'nombre' => 'Ficha temporal',
        'productos' => [$producto->id],
        'materiales' => [[
            'material_componente_id' => $material->id,
            'consumo_estandar' => 2,
            'unidad_medida' => 'und',
            'costo_asociado_teorico' => 200,
        ]],
    ], $ficha);
    echo 'ficha actualizada en Preparación: consumo=' . $ficha->fresh()->materiales()->first()->consumo_estandar . PHP_EOL;
} catch (Throwable $e) {
    echo 'ERR: ' . get_class($e) . ' — ' . $e->getMessage() . PHP_EOL;
} finally {
    DB::rollBack();
}

echo 'tras rollback: productos=' . Producto::count() . ' | OPs=' . OrdenProduccion::count() . PHP_EOL;
