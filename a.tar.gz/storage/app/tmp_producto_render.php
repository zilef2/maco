<?php

require __DIR__ . '/../../vendor/autoload.php';
$app = require __DIR__ . '/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$usuario = App\Models\User::whereHas('roles', fn ($q) => $q->whereIn('name', ['superadmin', 'admin']))
    ->whereNotNull('email_verified_at')->first();
Illuminate\Support\Facades\Auth::login($usuario);

$response = $kernel->handle(Illuminate\Http\Request::create('/Producto', 'GET'));
echo 'GET /Producto => ' . $response->getStatusCode() . PHP_EOL;

preg_match('/data-page="([^"]+)"/', $response->getContent(), $m);
$page = json_decode(html_entity_decode($m[1], ENT_QUOTES), true);
$fila = $page['props']['fromController']['data'][0] ?? null;

if ($fila) {
    foreach (['id', 'Codigo_interno', 'ficha_id', 'ficha_bloqueada', 'ficha_bloqueo_detalle'] as $clave) {
        echo '  ' . $clave . ' = ' . var_export($fila[$clave] ?? null, true) . PHP_EOL;
    }
    echo '  ficha_materiales = ' . json_encode($fila['ficha_materiales'] ?? null) . PHP_EOL;
    echo '  distribuciones = ' . json_encode($fila['distribuciones_por_tallas'] ?? null) . PHP_EOL;
}
