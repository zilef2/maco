<?php

require __DIR__ . '/settings.php';
require __DIR__ . '/auth.php';

use Alejo\Notificaciones\NotificacionesManager;
use App\Http\Controllers\{ LocaleController, NotificacionesController, RoleController, ParametrosController, PermissionController};
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::post('/locale/{locale}', [LocaleController::class, 'update'])->name('locale.update');

// Route::get('/', function () { return Inertia::render('Welcome'); })->name('home');
Route::get('/', function () {
    return redirect()->route('login');
})->name('home');



Route::get('dashboard', function () {
	return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth', 'verified')->group(function () {
	Route::resource('/role', RoleController::class)->except('create', 'show', 'edit');
	Route::post('/role/destroy-bulk', [RoleController::class, 'destroyBulk'])->name('role.destroy-bulk');
	Route::resource('/permission', PermissionController::class)->except('create', 'show', 'edit');
	Route::post('/permission/store-modulo', [PermissionController::class, 'storeModulo'])->name('permission.store-modulo');
	Route::post('/permission/destroy-bulk', [PermissionController::class, 'destroyBulk'])->name('permission.destroy-bulk');
	Route::resource('/Parametros', ParametrosController::class);
	Route::post('/Parametros/lista', [ParametrosController::class, 'storeLista'])->name('parametros.lista.store');
	
	//<editor-fold desc="User">
	Route::resource('/user', UserController::class);
	Route::post('/user/destroy-bulk', [UserController::class, 'destroyBulk'])->name('user.destroy-bulk');
	

    require __DIR__.'/pagoszilef.php';
    require __DIR__.'/solozilef.php';

	Route::resource("/Producto", \App\Http\Controllers\ProductoController::class);
	Route::post("/Producto/upload-excel", [\App\Http\Controllers\ProductoController::class, 'uploadExcel'])->name('Producto.upload-excel');
	Route::put("/Producto/{id}/distribucion", [\App\Http\Controllers\ProductoController::class, 'syncDistribucion'])->name('Producto.distribucion');
	
	Route::resource("/Talla", \App\Http\Controllers\TallaController::class);
	Route::resource("/OrdenProduccion", \App\Http\Controllers\OrdenProduccionController::class);
	Route::put("/OrdenProduccion/{id}/distribucion", [\App\Http\Controllers\OrdenProduccionController::class, 'syncDistribucion'])->name('OrdenProduccion.distribucion');
	Route::put("/OrdenProduccion/{id}/estado", [\App\Http\Controllers\OrdenProduccionController::class, 'cambiarEstado'])->name('OrdenProduccion.cambiarEstado');
	Route::put("/OrdenProduccion/{id}/cierre", [\App\Http\Controllers\OrdenProduccionController::class, 'guardarCierre'])->name('OrdenProduccion.cierre');
	Route::put("/OrdenProduccion/{id}/recepcion-borrador", [\App\Http\Controllers\OrdenProduccionController::class, 'guardarRecepcionBorrador'])->name('OrdenProduccion.recepcionBorrador');
	Route::post("/OrdenProduccion/borrador", [\App\Http\Controllers\OrdenProduccionController::class, 'guardarBorrador'])->name('OrdenProduccion.borrador');
	Route::get("/ProcesoExterno/materiales-op/{orden}", [\App\Http\Controllers\ProcesoExternoController::class, 'materialesOp'])->name('ProcesoExterno.materialesOp');
	Route::post("/ProcesoExterno/salida-op", [\App\Http\Controllers\ProcesoExternoController::class, 'salidaOp'])->name('ProcesoExterno.salidaOp');
	Route::resource("/ProcesoExterno", \App\Http\Controllers\ProcesoExternoController::class);
	Route::resource("/KitProceso", \App\Http\Controllers\KitProcesoController::class);
	Route::post("/KitProceso/upload-excel", [\App\Http\Controllers\KitProcesoController::class, 'uploadExcel'])->name('KitProceso.upload-excel');
	Route::get("/KitProceso/por-orden/{id}", [\App\Http\Controllers\KitProcesoController::class, 'porOrden'])->name('KitProceso.por-orden');
	Route::put("/KitProceso/por-orden/{id}", [\App\Http\Controllers\KitProcesoController::class, 'updatePorOrden'])->name('KitProceso.update-por-orden');
	Route::resource("/RecepcionCalidad", \App\Http\Controllers\RecepcionCalidadController::class);
	Route::resource("/CierreOrdenProduccion", \App\Http\Controllers\CierreOrdenProduccionController::class);
	Route::resource("/EstadoOperacion", \App\Http\Controllers\EstadoOperacionController::class);
	Route::post("/EstadoOperacion/upload-excel", [\App\Http\Controllers\EstadoOperacionController::class, 'uploadExcel'])->name('EstadoOperacion.upload-excel');
	Route::resource("/FichaTecnicaMateriales", \App\Http\Controllers\FichaTecnicaMaterialesController::class);
	Route::resource("/PendientesProduccion", \App\Http\Controllers\PendientesProduccionController::class);
	Route::resource("/Taller", \App\Http\Controllers\TallerController::class);
	Route::post("/Taller/upload-excel", [\App\Http\Controllers\TallerController::class, 'uploadExcel'])->name('Taller.upload-excel');
	Route::resource("/Proveedor", \App\Http\Controllers\ProveedorController::class);
	Route::post("/Proveedor/upload-excel", [\App\Http\Controllers\ProveedorController::class, 'uploadExcel'])->name('Proveedor.upload-excel');
	Route::resource("/Distribucion_por_tallas", \App\Http\Controllers\Distribucion_por_tallasController::class);
	Route::resource("/Material", \App\Http\Controllers\MaterialController::class);
	Route::post("/Material/upload-excel", [\App\Http\Controllers\MaterialController::class, 'uploadExcel'])->name('Material.upload-excel');
	Route::get('/Material/{id}/movimientos', [\App\Http\Controllers\MaterialController::class, 'historicoMovimientos'])->name('Material.movimientos');
	Route::resource("/GrupoTalla", \App\Http\Controllers\GrupoTallaController::class);
	Route::get("/ImportarExcel", [\App\Http\Controllers\ImportarExcelController::class, 'index'])->name('ImportarExcel.index');
	Route::post("/ImportarExcel/entidad", [\App\Http\Controllers\ImportarExcelController::class, 'toggleEntidad'])->name('ImportarExcel.toggleEntidad');
	Route::resource("/EstadoOpMaterial", \App\Http\Controllers\EstadoOpMaterialController::class);
	Route::resource("/EmpresaExterna", \App\Http\Controllers\EmpresaExternaController::class);
	Route::resource("/Merma", \App\Http\Controllers\MermaController::class);
	Route::resource("/FichaEnsamble", \App\Http\Controllers\FichaEnsambleController::class);
	Route::resource("/FichaEnsambleMaterial", \App\Http\Controllers\FichaEnsambleMaterialController::class);
	//aquipues
}); //fin verified



// <editor-fold desc="Artisan">
require __DIR__.'/ArtisanZilef.php';
require __DIR__.'/Routes_entrega1.php';
