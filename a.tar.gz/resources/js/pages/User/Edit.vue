<script setup lang="ts">
import InputError from '@/components/InputError.vue';
import InputLabel from '@/components/InputLabel.vue';
import Modal from '@/components/Modal.vue';
import PrimaryButton from '@/components/PrimaryButton.vue';
import SecondaryButton from '@/components/SecondaryButton.vue';
import SelectInput from '@/components/SelectInput.vue';
import TextInput from '@/components/TextInput.vue';
import { useForm } from '@inertiajs/vue3';
import { watchEffect, onMounted, reactive, ref } from 'vue';
declare const lang: any;
declare const route: any;
import { VueDatePicker } from '@vuepic/vue-datepicker'; import '@vuepic/vue-datepicker/dist/main.css'
import vSelect from "vue-select"; import "vue-select/dist/vue-select.css";

const props = defineProps({
    show: Boolean,
    title: String,
    user: Object as any,
    titulos: { type: Array as any, default: () => [] }, //parametros de la clase principal
    roles: { type: Array as any, default: () => [] },
})

const emit = defineEmits(["close"]);
const data = reactive({
    params: {
        pregunta: ''
    },
    onceTime: true,
    sexo: [{ title: 'Masculino', value: 'Masculino' }, { title: 'Femenino', value: 'Femenino' }]
})
//very usefull
const justNames = props.titulos.map((names: any) => names['order'])
const form = useForm<Record<string, any>>({
    ...Object.fromEntries(justNames.map((field: string) => [field, ''])),
    role: ''
});

const printForm: any[] = [];
props.titulos.forEach((names: any) => printForm.push({
    idd: names['order'], label: names['label'], type: names['type']
})
);



watchEffect(() => {
    if (props.show) {
        form.errors = {}
        // if(data.onceTime){

        form.name = props.user?.name
        form.email = props.user?.email
        form.role = props.user?.roles == 0 ? '' : props.user?.roles[0].name

        form.identificacion = props.user?.identificacion
        form.sexo = props.user?.sexo
        console.log('sex',props.user)
        form.fecha_nacimiento = props.user?.fecha_nacimiento
        form.celular = props.user?.celular
        form.area = props.user?.area
        form.cargo = props.user?.cargo
        data.onceTime = false
        // }
    } else {
        form.name = null
        form.email = null
        form.role = null

        form.identificacion = null
        form.sexo = null
        form.fecha_nacimiento = null
        form.celular = null
        form.area = null
        form.cargo = null
    }
})

onMounted(() => { });

const roles = props.roles?.map((role: any) => ({
    label: role.name.replace(/_/g, " "),
    value: (role.name)
}))

const formatToVue = (date: any) => {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();

    return `${day}/${month}/${year}`;
}


const update = () => {
    // alert(JSON.stringify(props.user, null, 2))
    form.put(route('user.update', props.user?.id), {
        
        preserveScroll: true,
        onSuccess: () => {
            emit("close")
            form.reset()
        },
         onError: (errors) => {
            const first = Object.values(errors)[0]
            alert(first ?? 'Error al actualizar')
         },
        onFinish: () => null,
    })
}

const daynames = ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom'];
const flow = ref<any>(['year', 'month', 'calendar']);
</script>

<template>
    <section class="space-y-6">
        <Modal :show="props.show" @close="emit('close')">
            <form class="p-6 mb-12" @submit.prevent="update">
                <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                    {{ lang().t('app.label.edit') }} {{ props.title }}
                </h2>
                <h3 class="font-medium text-gray-900 dark:text-gray-100 mb-2">
                    {{ lang().t('app.label.RequiredFields') }}
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div v-for="(atributosform, indice) in printForm" :key="indice">

                        <!-- si es foreign -->
                        <div v-if="atributosform.type === 'foreign'" id="SelectVue" class="mt-2">
                            <div class="inline-flex">
                                <label name="labelSelectVue"> {{ atributosform.label }} </label>
                                <small class="text-lg ml-1 font-bold"> {{ titulos[indice].required ? '*' : 'ㅤ' }}
                                </small>
                            </div>
                            <v-select :options="data[atributosform.idd]" label="title" class="text-lg h-8"
                                v-model="form[atributosform.idd]"></v-select>
                            <InputError class="mt-2" :message="form.errors[atributosform.idd]" />
                        </div>


                        <!-- tiempo -->
                        <div v-else-if="atributosform.type === 'time'" id="SelectVue">
                            <div class="inline-flex">
                                <InputLabel :for="atributosform.label"
                                    :value="lang().t('app.label')[atributosform.label]" />
                                <small class="text-lg ml-1 font-bold"> {{ titulos[indice].required ? '*' : 'ㅤ' }}
                                </small>
                            </div>
                            <TextInput :id="atributosform.idd" :type="atributosform.type" class="mt-1 block w-full"
                                v-model="form[atributosform.idd]" required :placeholder="atributosform.label"
                                :error="form.errors[atributosform.idd]" step="3600" />
                            <InputError class="mt-2" :message="form.errors[atributosform.idd]" />
                        </div>
                        <div v-else-if="atributosform.type === 'date'" id="SelectVue">
                            <div class="inline-flex">
                                <InputLabel :for="atributosform.label"
                                    :value="lang().t('app.label')[atributosform.label]" />
                                <small class="text-lg ml-1 font-bold"> {{ titulos[indice].required ? '*' : 'ㅤ' }}
                                </small>
                            </div>
                            <VueDatePicker :is-24="false" :day-names="daynames" :format="formatToVue" :flow="flow"
                                auto-apply :enable-time-picker="false" :id="atributosform.idd" class="mt-1 block w-full"
                                v-model="form[atributosform.idd]" model-type="yyyy-MM-dd" required
                                :placeholder="atributosform.label" :error="form.errors[atributosform.idd]" />
                            <InputError class="mt-2" :message="form.errors[atributosform.idd]" />
                        </div>


                        <!-- normal -->
                        <div v-else class="">
                            <div class="inline-flex">
                                <InputLabel :for="atributosform.label"
                                    :value="lang().t('app.label')[atributosform.label]" />
                                <small class="text-lg ml-1 font-bold"> {{ titulos[indice].required ? '*' : 'ㅤ' }}
                                </small>
                            </div>
                            <TextInput :id="atributosform.idd" :type="atributosform.type" class="mt-1 block w-full"
                                v-model="form[atributosform.idd]" required :placeholder="atributosform.label"
                                :error="form.errors[atributosform.idd]" />
                            <InputError class="mt-2" :message="form.errors[atributosform.idd]" />
                        </div>
                    </div>

                    <div>
                        <div class="inline-flex">
                            <InputLabel for="role" :value="lang().t('app.label.role')" /><small
                                class="text-lg ml-1 font-bold"> *
                            </small>
                        </div>
                        <SelectInput id="role" class="mt-1 block w-full" v-model="form.role" required :dataSet="roles">
                        </SelectInput>
                        <InputError class="mt-2" :message="form.errors.role" />
                    </div>

                </div>



                <!-- limite_token_general -->


                <!-- pass -->
                <!-- <div>
                        <InputLabel for="password" :value="lang().t('app.label.password')" />
                        <TextInput id="password" type="password" class="mt-1 block w-full" v-model="form.password"
                            :placeholder="lang().t('app.placeholder.password')" :error="form.errors.password" />
                        <InputError class="mt-2" :message="form.errors.password" />
                    </div>
                    <div>
                        <InputLabel for="password_confirmation" :value="lang().t('app.label.password_confirmation')" />
                        <TextInput id="password_confirmation" type="password" class="mt-1 block w-full"
                            v-model="form.password_confirmation" :placeholder="lang().t('app.placeholder.password_confirmation')"
                            :error="form.errors.password_confirmation" />
                        <InputError class="mt-2" :message="form.errors.password_confirmation" />
                    </div> -->


                <div class="flex justify-end my-8">
                    <div v-for="(atributosform, indice) in printForm" :key="indice">
                        <div v-if="form.errors[atributosform]" class="text-red-500">
                            {{ form.errors[atributosform] }}
                        </div>
                    </div>
                </div>
                <div class="flex justify-end my-8">
                    <SecondaryButton :disabled="form.processing" @click="emit('close')"> {{ lang().t('app.button.close')
                    }}
                    </SecondaryButton>
                    <PrimaryButton class="ml-3" :class="{ 'opacity-25': form.processing }" :disabled="form.processing"
                        @click="update">
                        {{ form.processing ? lang().t('app.button.save') + '...' : lang().t('app.button.save') }}
                    </PrimaryButton>
                </div>
            </form>
        </Modal>
    </section>
</template>
