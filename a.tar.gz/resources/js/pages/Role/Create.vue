<script setup lang="ts">
import InputError from '@/components/InputError.vue';
import InputLabel from '@/components/InputLabel.vue';
import Modal from '@/components/Modal.vue';
import PrimaryButton from '@/components/PrimaryButton.vue';
import SecondaryButton from '@/components/SecondaryButton.vue';
import TextInput from '@/components/TextInput.vue';
import { useForm } from '@inertiajs/vue3';
import Checkbox from '@/components/Checkbox.vue';
import { reactive, watchEffect } from 'vue';

const props = defineProps({
    show: Boolean,
    title: String,
    permissions: Object,
})

const emit = defineEmits(["close"]);

const data = reactive({
    multipleSelect: false,
})

const form = useForm({
    name: '',
    guard_name: 'web',
    permissions: [],
})

const create = () => {
    form.post(route('role.store'), {
        preserveScroll: true,
        onSuccess: () => {
            emit("close")
            form.reset()
            data.multipleSelect = false
        },
        onError: () => null,
        onFinish: () => null,
    })
}

watchEffect(() => {
    if (props.show) {
        form.errors = {}
    }
})

const selectAll = (event) => {
    if (event.target.checked === false) {
        form.permissions = []
    } else {
        form.permissions = []
        props.permissions.forEach((permission) => {
            form.permissions.push(permission.id)
        })
    }
}
const select = () => {
    if (props.permissions.length == form.permissions.length) {
        data.multipleSelect = true
    } else {
        data.multipleSelect = false
    }
}

</script>

<template>
    <section class="space-y-6">
        <Modal :show="props.show" @close="emit('close')">
            <form class="p-6" @submit.prevent="create">
                <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {{ lang().t('app.label.add') }} {{ props.title }}
                </h2>
                <div class="my-6 space-y-4">
                    <div>
                        <InputLabel for="name" :value="lang().t('app.label.role')" />
                        <TextInput id="name" type="text" class="mt-1 block w-full" v-model="form.name" required
                            :placeholder="lang().t('app.placeholder.name')" :error="form.errors.name" />
                        <InputError class="mt-2" :message="form.errors.name" />
                    </div>
                    <div>
                        <InputLabel :value="lang().t('app.label.permission')" />
                        <InputError class="mt-2" :message="form.errors.permissions" />
                        <div class="flex justify-start items-center space-x-2 mt-2">
                            <Checkbox id="permission-all" v-model:checked="data.multipleSelect" @change="selectAll" />
                            <InputLabel for="permission-all" :value="lang().t('app.label.check_all')" />
                        </div>
                        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 mt-2">
                            <div class="flex items-center justify-start space-x-2"
                                v-for="(permission, index) in props.permissions" :key="index">
                                <input @change="select"
                                    class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-primary dark:text-primary shadow-sm focus:ring-primary/80 dark:focus:ring-primary dark:focus:ring-offset-gray-800 dark:checked:bg-primary dark:checked:border-primary"
                                    type="checkbox" :id="'permission_' + permission.id" :value="permission.id"
                                    v-model="form.permissions" />
                                <InputLabel :for="'permission_' + permission.id" :value="permission.name" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex justify-end">
                    <SecondaryButton :disabled="form.processing" @click="emit('close')"> {{ lang().t('app.button.close')
                        }}
                    </SecondaryButton>
                    <PrimaryButton class="ml-3" :class="{ 'opacity-25': form.processing }" :disabled="form.processing"
                        @click="create">
                        {{ form.processing ? lang().t('app.button.add') + '...' : lang().t('app.button.add') }}
                    </PrimaryButton>
                </div>
            </form>
        </Modal>
    </section>
</template>
