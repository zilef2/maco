<script setup lang="ts">
import Modal from '@/components/Modal.vue';
import SecondaryButton from '@/components/SecondaryButton.vue';

const props = defineProps({
    show: Boolean,
    title: String,
    role: Object,
})

const emit = defineEmits(["close"]);

</script>

<template>
    <section class="space-y-6">
        <Modal :show="props.show" @close="emit('close')" :maxWidth="'2xl'">
            <div class="p-6 text-gray-900 dark:text-gray-100">
                <h2 class="text-lg font-medium">
                    {{ lang().t('app.label.permission') }}
                </h2>
                <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    {{ lang().t('app.label.all_permission') }} {{ lang().t('app.label.role') }} <b>{{
                        props.role?.name }}</b>
                </p>
                <div class="my-6 grid grid-cols-2 sm:grid-cols-3">
                    <div v-for="(permission, index) in props.role?.permissions" :key="index"
                        class="flex justify-between w-full px-4 py-2 ">
                        {{ ++index + ". " + permission.name }}
                    </div>
                </div>
                <div class="mt-6 flex justify-end">
                    <SecondaryButton @click="emit('close')"> {{ lang().t('app.button.close') }}
                    </SecondaryButton>
                </div>
            </div>
        </Modal>
    </section>
</template>
