<script setup lang="ts">
import AppLayout from '@/layouts/AppLayout.vue';
import { Head, usePage } from '@inertiajs/vue3';
import Breadcrumb from '@/components/Breadcrumb.vue';
import TextInput from '@/components/TextInput.vue';
import PrimaryButton from '@/components/PrimaryButton.vue';
import InfoButton from '@/components/InfoButton.vue';
import { reactive, watch } from 'vue';
import DangerButton from '@/components/DangerButton.vue';
import pkg from 'lodash';
import { router } from '@inertiajs/vue3';
import Pagination from '@/components/Pagination.vue';
import { ChevronUpDownIcon, PencilIcon, TrashIcon } from '@heroicons/vue/24/solid';
import Create from '@/pages/Role/Create.vue';
import Edit from '@/pages/Role/Edit.vue';
import Delete from '@/pages/Role/Delete.vue';
import DeleteBulk from '@/pages/Role/DeleteBulk.vue';
import Checkbox from '@/components/Checkbox.vue';
import SelectInput from '@/components/SelectInput.vue';
import Permission from '@/pages/Role/Permission.vue';
import CrearCuatroPermisos from '@/components/CrearCuatroPermisos.vue';

const { _, debounce, pickBy } = pkg
const props = defineProps({
    title: String,
    filters: Object,
    roles: Object,
    permissions: Object,
    breadcrumbs: Object,
    perPage: Number,
    numberPermissions: Number,
})
const defaultPerPage = [
    { label: '5', value: 5 },
    { label: '10', value: 10 },
    { label: '25', value: 25 },
    { label: '50', value: 50 },
    { label: '100', value: 100 },
];

const data = reactive({
    params: {
        search: props.filters?.search,
        field: props.filters?.field,
        order: props.filters?.order,
        perPage: props.perPage,
    },
    selectedId: [] as number[],
    crearPermisosOpen: false,
    multipleSelect: false,
    createOpen: false,
    editOpen: false,
    deleteOpen: false,
    deleteBulkOpen: false,
    permissionOpen: false,
    role: null as any,
    dataSet: (usePage().props as any)?.app?.perpage ?? defaultPerPage,
})

const order = (field: string) => {
    data.params.field = field
    data.params.order = data.params.order === "asc" ? "desc" : "asc"
}

watch(() => _.cloneDeep(data.params), debounce(() => {
    const params = pickBy(data.params)
    router.get(route("role.index"), params, {
        replace: true,
        preserveState: true,
        preserveScroll: true,
    })
}, 150))

const selectAll = (event: any) => {
    if (event.target.checked === false) {
        data.selectedId = []
    } else {
        props.roles?.data.forEach((role: any) => {
            data.selectedId.push(role.id)
        })
    }
}
const select = () => {
    if (props.roles?.data.length == data.selectedId.length) {
        data.multipleSelect = true
    } else {
        data.multipleSelect = false
    }
}

</script>

<template>

    <Head :title="props.title" />

    <AppLayout>
        <Breadcrumb :title="title" :breadcrumbs="breadcrumbs" />
        <div class="space-y-4">
            <div class="px-4 sm:px-0">
                <div class="rounded-lg overflow-hidden w-fit">
                    <PrimaryButton v-show="can(['create role'])" @click="data.createOpen = true" class="m-1">
                        {{ lang().t('app.button.add') }}
                    </PrimaryButton>
                    <PrimaryButton class="m-1 bg-indigo-600 hover:bg-indigo-700" @click="data.crearPermisosOpen = true">
                        Crear 4 permisos
                    </PrimaryButton>
                    <CrearCuatroPermisos :show="data.crearPermisosOpen" modulo="materiales"
                        @close="data.crearPermisosOpen = false" />

                    <Create :show="data.createOpen" @close="data.createOpen = false" :permissions="props.permissions"
                        :title="props.title" />
                    <Create :show="data.createOpen" @close="data.createOpen = false" :permissions="props.permissions"
                        :title="props.title" />
                    <Edit :show="data.editOpen" @close="data.editOpen = false" :role="data.role"
                        :permissions="props.permissions" :title="props.title" />
                    <Delete :show="data.deleteOpen" @close="data.deleteOpen = false" :role="data.role"
                        :title="props.title" />
                    <DeleteBulk :show="data.deleteBulkOpen"
                        @close="data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []"
                        :selectedId="data.selectedId" :title="props.title" />
                    <Permission :show="data.permissionOpen" @close="data.permissionOpen = false" :role="data.role"
                        :title="props.title" />
                </div>
            </div>
            <div class="relative bg-white dark:bg-gray-800 shadow sm:rounded-lg w-max min-w-full">
                <div class="flex justify-between p-2">
                    <div class="flex space-x-2">
                        <SelectInput v-model="data.params.perPage" :dataSet="data.dataSet" />
                        <DangerButton @click="data.deleteBulkOpen = true"
                            v-show="data.selectedId.length != 0 && can(['delete role'])" class="px-3 py-1.5"
                            v-tooltip="lang().t('app.tooltip.delete_selected')">
                            <TrashIcon class="w-5 h-5" />
                        </DangerButton>
                    </div>
                    <TextInput v-if="props.numberPermissions && props.numberPermissions > 1"
                        v-model="data.params.search" type="text" class="block w-3/6 md:w-2/6 lg:w-1/6 rounded-lg"
                        :placeholder="lang().t('app.placeholder.search')" />
                </div>
                <div>
                    <table class="w-full">
                        <thead class="uppercase text-sm border-t border-gray-200 dark:border-gray-700">
                            <tr class="dark:bg-gray-900/50 text-left">
                                <th class="px-2 py-4 text-center">
                                    <Checkbox v-model:checked="data.multipleSelect" @change="selectAll" />
                                </th>
                                <th class="px-2 py-4 text-center">#</th>
                                <th class="px-2 py-4 cursor-pointer" v-on:click="order('name')">
                                    <div class="flex justify-between items-center">
                                        <span>{{ lang().t('app.label.name') }}</span>
                                        <ChevronUpDownIcon class="w-4 h-4" />
                                    </div>
                                </th>
                                <th class="px-2 py-4 cursor-pointer" v-on:click="order('email')">
                                    <div class="flex justify-between items-center">
                                        <span>Guard</span>
                                        <ChevronUpDownIcon class="w-4 h-4" />
                                    </div>
                                </th>
                                <th class="px-2 py-4">{{ lang().t('app.label.permission') }}</th>
                                <th class="px-2 py-4 cursor-pointer" v-on:click="order('updated_at')">
                                    <div class="flex justify-between items-center">
                                        <span>{{ lang().t('app.label.updated') }}</span>
                                        <ChevronUpDownIcon class="w-4 h-4" />
                                    </div>
                                </th>
                                <th class="px-2 py-4 sr-only">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(role, index) in roles?.data" :key="index"
                                class="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-200/30 hover:dark:bg-gray-900/20">
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center">
                                    <input
                                        class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-primary dark:text-primary shadow-sm focus:ring-primary/80 dark:focus:ring-primary dark:focus:ring-offset-gray-800 dark:checked:bg-primary dark:checked:border-primary"
                                        type="checkbox" @change="select" :value="role.id" v-model="data.selectedId" />
                                </td>
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center">{{ index + 1 }}</td>
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3">{{ role.name.replace(/_/g, " ") }}</td>
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3">{{ role.guard_name }}</td>
                                <td v-tooltip="lang().t('app.tooltip.detail')"
                                    v-if="role.permissions.length == props.permissions?.length"
                                    @click="(data.permissionOpen = true), (data.role = role)"
                                    class="whitespace-nowrap py-4 px-2 sm:py-3 cursor-pointer text-blue-600 dark:text-blue-400 font-bold underline">
                                    {{ lang().t('app.label.all_permission') }}
                                </td>

                                <td v-tooltip="lang().t('app.tooltip.detail')" v-else-if="role.permissions.length != 0"
                                    @click="(data.permissionOpen = true), (data.role = role)"
                                    class="whitespace-nowrap py-4 px-2 sm:py-3 cursor-pointer text-blue-600 dark:text-blue-400 font-bold underline">
                                    {{ role.permissions.length }} {{ lang().t('app.label.permission') }}</td>
                                <td v-else class="whitespace-nowrap py-4 px-2 sm:py-3">{{
                                    lang().t('app.label.no_permission') }}
                                </td>
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3">{{ role.updated_at }}</td>
                                <td class="whitespace-nowrap py-4 px-2 sm:py-3">
                                    <div class="flex justify-center items-center">
                                        <div class="rounded-md overflow-hidden">
                                            <InfoButton v-show="can(['update role'])" type="button"
                                                @click="(data.editOpen = true), (data.role = role)"
                                                class="px-2 py-1.5 rounded-none"
                                                v-tooltip="lang().t('app.tooltip.edit')">
                                                <PencilIcon class="w-4 h-4" />
                                            </InfoButton>
                                            <DangerButton v-show="can(['delete role'])" type="button"
                                                @click="(data.deleteOpen = true), (data.role = role)"
                                                class="px-2 py-1.5 rounded-none"
                                                v-tooltip="lang().t('app.tooltip.delete')">
                                                <TrashIcon class="w-4 h-4" />
                                            </DangerButton>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="flex justify-between items-center p-2 border-t border-gray-200 dark:border-gray-700">
                    <Pagination :links="props.roles" :filters="data.params" />
                </div>
            </div>
        </div>
    </AppLayout>
</template>
