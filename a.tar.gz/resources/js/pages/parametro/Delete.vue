<script setup>
import DangerButton from '@/components/DangerButton.vue';
import Modal from '@/components/Modal.vue';
import SecondaryButton from '@/components/SecondaryButton.vue';
import { useForm } from '@inertiajs/vue3';


const props = defineProps({
    show: Boolean,
    title: String,
    ejercicio: Object,
})

const emit = defineEmits(["close"]);

const form = useForm({});

const destory = () => {
    form.delete(route('ejercicio.destroy', props.ejercicio?.id), {
        preserveScroll: true,
        onSuccess: () => {
            emit("close")
            form.reset()
        },
        onError: () => null,
        onFinish: () => null,
    })
}

</script>

<template>
    <section class="space-y-6">
        <Modal :show="props.show" @close="emit('close')" :maxWidth="'lg'">
            <form class="p-6" @submit.prevent="destory">
                <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {{ lang().t('app.label.delete') }} {{ props.title }}
                    a: {{ props.ejercicio.id }}
                </h2>
                <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    {{ lang().t('app.label.delete_confirm') }} <b>{{ props.CentroCosto?.nombre }} !?</b>
                </p>
                <div class="mt-6 flex justify-end">
                    <SecondaryButton :disabled="form.processing" @click="emit('close')"> {{ lang().t('app.button.close')
                        }}
                    </SecondaryButton>
                    <DangerButton class="ml-3" :class="{ 'opacity-25': form.processing }" :disabled="form.processing"
                        @click="destory">
                        {{ form.processing ? lang().t('app.button.delete') + '...' : lang().t('app.button.delete') }}
                    </DangerButton>
                </div>
            </form>
        </Modal>
    </section>
</template>
