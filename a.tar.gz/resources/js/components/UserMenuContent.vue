<script setup lang="ts">
import UserInfo from '@/components/UserInfo.vue';
import { DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import type { User } from '@/types';
import { Link } from '@inertiajs/vue3';
import { KeyRound, LogOut, Settings, Shield, SlidersHorizontal, Users } from 'lucide-vue-next';

interface Props {
    user: User;
}

defineProps<Props>();
</script>

<template>
    <DropdownMenuLabel class="p-0 font-normal">
        <div class="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
            <UserInfo :user="user" :show-email="true" />
        </div>
    </DropdownMenuLabel>
    <DropdownMenuSeparator />
    <DropdownMenuGroup>
        <DropdownMenuItem :as-child="true">
            <Link class="block w-full" :href="route('user.index')" as="button">
                <Users class="mr-2 h-4 w-4" />
                Personas
            </Link>
        </DropdownMenuItem>
        <DropdownMenuItem :as-child="true">
            <Link class="block w-full" :href="route('profile.edit')" as="button">
                <Settings class="mr-2 h-4 w-4" />
                Ajustes
            </Link>
        </DropdownMenuItem>
        <DropdownMenuItem :as-child="true" v-if="can(['issuperadmin'])">
            <Link class="block w-full" method="get" :href="route('Parametros.index')" as="button">
                <SlidersHorizontal class="mr-2 h-4 w-4" />
                Parametros
            </Link>
        </DropdownMenuItem>
        <DropdownMenuItem :as-child="true" v-if="can(['issuperadmin'])">
            <Link class="block w-full" method="get" href="/role" as="button">
                <Shield class="mr-2 h-4 w-4" />
                Roles
            </Link>
        </DropdownMenuItem>
        <DropdownMenuItem :as-child="true" v-if="can(['issuperadmin'])">
            <Link class="block w-full" method="get" href="/permission" as="button">
                <KeyRound class="mr-2 h-4 w-4" />
                Permisos
            </Link>
        </DropdownMenuItem>
    </DropdownMenuGroup>
    <DropdownMenuSeparator />
    <DropdownMenuItem :as-child="true">
        <Link class="block w-full" method="post" :href="route('logout')" as="button">
            <LogOut class="mr-2 h-4 w-4" />
            Cerrar sesión
        </Link>
    </DropdownMenuItem>
</template>
